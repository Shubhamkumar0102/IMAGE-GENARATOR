$(".menu").click(function(){
    $(".navigation").removeClass(".hidden");
    $(".navigation").slideToggle();
})

// parallaxJs
var text = document.getElementById('text');
var parallaxInstance = new Parallax(text);

var png1 = document.getElementById('png1');
var parallaxInstance = new Parallax(png1);

var png2 = document.getElementById('png2');
var parallaxInstance = new Parallax(png2);

var png3 = document.getElementById('png3');
var parallaxInstance = new Parallax(png3);

var png4 = document.getElementById('png4');
var parallaxInstance = new Parallax(png4);

var png5 = document.getElementById('png5');
var parallaxInstance = new Parallax(png5);

var png6 = document.getElementById('png6');
var parallaxInstance = new Parallax(png6);